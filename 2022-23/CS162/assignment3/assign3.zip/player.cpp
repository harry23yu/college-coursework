#include <iostream>
#include <string>
#include "hand.h"
#include "player.h"
using namespace std;

Player::Player() {
    cout << "Player 1 cards: ";
    /*for(int i = 0; i < 7 ; i++) {
        hand.addCardToPlayer();
    }*/
}