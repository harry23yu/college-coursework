#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "card.h"
#include "deck.h"
using namespace std;

Deck::Deck() { //default constructor
    srand(time(0));
    int i = 0;
    this->n_cards = 52; //52 cards at the beginning of game
    for(int j = 0; j < 13; j++) {
        for(int k = 0; k < 4; k++) {
            cards[i].set_rank(j);
            cards[i].set_suit(k);
            i++;
        }
    }
    for(int i = 0; i < 52; i++) {
        int m = i + (rand() % (52 - i));
        swap(cards[i], cards[m]);
        cards[i].print_card();
    }
}

Card Deck::drawCardFromDeck() {
    Card tempCards = this->cards[n_cards];
    this->n_cards = this->n_cards-1;
    return tempCards;
}

Card Deck::get_cards() { //accessor
    return this->cards[n_cards];
}

int Deck::get_n_cards() { //accessor
    return this->n_cards;
}