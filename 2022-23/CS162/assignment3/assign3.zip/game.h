#ifndef GAME_H
#define GAME_H
using namespace std;

#include <iostream>
#include <string>

#include "player.h"
#include "deck.h"

class Game {
    private:
        Deck d;
        Player players[2];
    public:
        //constructors
        Game();
        //destructor

        //accessors

        //mutators

        //other member functions
        void nextPlayerTurn();
        void isGameOver();
};

#endif