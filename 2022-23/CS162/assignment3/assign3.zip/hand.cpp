#include <iostream>
#include <string>
#include "deck.h"
#include "hand.h"
using namespace std;

Hand::Hand() {
    this->cards = new Card[7];
    this->cards = 0;
}

Hand::Hand(Card*& deck_cards) {
    //Insert code here
}

void Hand::addCardToPlayer() {
    this->cards[n_cards] = cards[n_cards];
    this->cards[n_cards].print_card();
    this->n_cards++;
}