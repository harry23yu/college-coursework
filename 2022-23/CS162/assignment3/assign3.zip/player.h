#ifndef PLAYER_H
#define PLAYER_H
using namespace std;

#include <iostream>
#include <string>

#include "card.h"
#include "deck.h"
#include "hand.h"

class Player {
    private:
        Hand hand;
        int* books; // Array with ranks for which the player has books.
        int n_books;
    public:
        //constructors
        Player();
        //destructor

        //accessors

        //mutators

        //other member functions
        void addCardToPlayer();
        void removeCardFromPlayer();
        void askForRank();
};

#endif