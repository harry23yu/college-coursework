#include <iostream>
#include <string.h>
#include "card.h"
#include "deck.h"
#include "hand.h"
#include "player.h"
#include "game.h"
using namespace std;

int main() {
    Deck deckOfCards;
    //Hand playerOne(deckOfCards.);
    deckOfCards.drawCardFromDeck();
    Hand handOne;
    Player playerOne;
    return 0;
}